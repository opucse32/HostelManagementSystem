<center><b>Admission 2017-18</b><br><br>

Admission open in first week of every month<br><br>

<b>PG cources-:</b><br><br>
Branches:<br>

Computer Science & Engineering (100 seats)<br>
Electronics & Electrical Engineering (100 seats)<br>
Information & Technology (100 seats)<br>
Bachelor of Business(100 seats)<br>
English Literature (100 seats)<br>
Low & Justice (100 seats)<br>
Economics<br><br>

<b>UG cources-:</b><br><br>

Master of Bussiness Management(MBA)<br>
Master of Computer Applications<br>
M.TECH(CSE,EEE,IT,BBA,ENG,ECO)</center>