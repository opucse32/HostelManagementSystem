<center><h1>Campus Drive</h1></center>

<center>BUET - <b>CSE Fest</b> - 17th July '14<br><br>

SUST - <b>Inter University Programming Contest</b> - 28th July '15<br><br>

DU - <b>Inter University Sports Contest</b> - 8th august '16<br><br>

MBSTU- <b>Photographic Exibition</b> - 18th Aug '17</center>