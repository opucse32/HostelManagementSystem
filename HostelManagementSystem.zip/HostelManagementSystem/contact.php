<h1 style="color:#000000"><b><center>Contact Details</center></b></h1>
<div align="center">
<p><b>Address :</b> Metropolitan University Hostel, Jollar Par, Zindabazar, Sylhet.
<p><b>Phone :</b> +88-0821-713077-8<br>
<b>Fax :</b> +88-0821-713304
</p>
<p><b>Email :</b> info@metrouni.edu.bd</p>
</p>
</div>