<h1><center>Courses Offered</center></h1>
<div align="center">
<table width="725" height="346" border="1">
  <tbody>
    <tr>
      <td height="30" bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Course</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Intake</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Duration</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Other</b></font></center></td>
    </tr>
    <tr>
      <td colspan="4" bgcolor="#A1AAF3"><center><font size="+1"><b>Undergraduate Program</b></font></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Computer Science & Engineering</b></center></td>
      <td bgcolor="#97CDDB"><center><b>100</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Vocational Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Electronics & Electrical Engineering</b></center></td>
      <td bgcolor="#97CDDB"><center><b>100</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Vocational Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Information & Technology</b></center></td>
      <td bgcolor="#97CDDB"><center><b>100</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Field Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>English Literature</b></center></td>
      <td bgcolor="#97CDDB"><center><b>100</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Field Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Low & Justice</b></center></td>
      <td bgcolor="#97CDDB"><center><b>100</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Field Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Bachelor of Business</b></center></td>
      <td bgcolor="#97CDDB"><center><b>100</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Company Visits</b></center></td>
    </tr>
  </tbody>
</table>
<p>&nbsp;	</p>
<table width="725" height="246" border="1">
  <tbody>
    <tr>
      <td height="30" bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Course</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Intake</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Duration</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Other</b></font></center></td>
    </tr>
    <tr>
      <td height="72" colspan="4" bgcolor="#A1AAF3"><center>
        <font size="+1"><b>Postgraduate raduate Programs</b></font>
      </center></td>
    </tr>
    <tr>
      <td height="59" bgcolor="#B4BEDC"><center><b>Master of Bussiness Management(MBA)</b></center></td>
      <td bgcolor="#97CDDB"><center>
        <b>30</b>
      </center></td>
      <td bgcolor="#B4BEDC"><center>
        <b>2 Years</b>
      </center></td>
      <td bgcolor="#97CDDB"><center>
        <b>Foreign Trip &amp; Faculty Induction Programme</b>
      </center></td>
    </tr>
    <tr>
      <td height="51" bgcolor="#B4BEDC"><center><b>Master of Computer Applications</b></center></td>
      <td bgcolor="#97CDDB"><center>
        <b>30</b>
      </center></td>
      <td bgcolor="#B4BEDC"><center>
        <b>2 Years</b>
      </center></td>
      <td bgcolor="#97CDDB"><center>
        <b>Vocational Training &amp; Foreign Trip</b>
      </center></td>
    </tr>
  </tbody>
</table>
</div>
