
<center><b>Notice Board:</b><br><br>

Summer Term Final Exam Will be Start From 20th August 2017<br><br>

Summer Term Final Exam Ending 27th August 2017<br><br>

Vacation Starts From 28th August 2017<br></center>