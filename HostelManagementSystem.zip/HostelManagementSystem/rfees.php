<div align="center">
<h1 style="color:#5B5B5B"><u>ROOM FEES</u></h1>
<table width="1045" height="213" border="1">
  <tbody>
    <tr>
      <td width="241" height="35"><center>ROOM</center></td>
      <td width="121"><center>First Instalment</center></td>
      <td width="133"><center>Monthly Cost</center></td>
      <td width="522"><center>Totak(One Year)</center></td>
    </tr>
    <tr>
      <td height="57"><center>Single</center></td>
      <td><center>TK 10,000/-</center></td>
      <td><center>TK 5,000/-</center></td>
      <td><center>TK 70,000/-</center></td>
    </tr>
    <tr>
      <td height="52"><center>Double</center></td>
      <td><center>TK 10,000/-</center></td>
      <td><center>TK 4,500/-</center></td>
      <td><center>TK 64,000/-</center></td>
    </tr>
    <tr>
      <td><center>Triple</center></td>
      <td><center>TK 10,000/-</center></td>
      <td><center>TK 4,000/-</center></td>
      <td><center>TK 58,000/-</center></td>
    </tr>
  </tbody>
</table>
</div>
