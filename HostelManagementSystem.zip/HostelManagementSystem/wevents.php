<center><b>Weekend events:<b><br><br>

Debate competiton(E/H)<br>

Intra University Programming Contest<br>

Indoor Game competition<br></center>